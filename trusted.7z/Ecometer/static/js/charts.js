/* ==========================================================================
   Green Meter App - Charts, UI & Recommendations (Plotly + Fetch)
   Wires: index.html  <->  Flask backend (formulas.py)
   Endpoints:
     - GET    /load_sample
     - POST   /calculate
     - POST   /reset

   Premium features in this file:
   - KPI widgets live update
   - Plotly Pie (optimized shares) + Grouped Bar (baseline vs optimized)
   - Live slider readouts
   - Recommendations panel (emoji icons, color-coded, animated)
   - Assumptions renderer
   - Robust error handling + a lightweight toast system
   ========================================================================== */

/* ------------------------------
   Category & Color Configuration
   ------------------------------ */
const CATEGORY_ORDER = [
  "cars",
  "trucks",
  "buses",
  "forklifts",
  "cargo_planes",
  "office_lighting",
  "heating",
  "cooling",
  "computing",
  "subcontractors",
];

const CATEGORY_LABELS = {
  cars: "Cars",
  trucks: "Trucks",
  buses: "Buses",
  forklifts: "Forklifts",
  cargo_planes: "Cargo Planes",
  office_lighting: "Office Lighting",
  heating: "Heating",
  cooling: "Cooling",
  computing: "Computing",
  subcontractors: "Subcontractors",
};

// Minimal, modern, accessible palette
const CATEGORY_COLORS = {
  cars: "#66e0a3",
  trucks: "#2bd3c6",
  buses: "#7aa2f7",
  forklifts: "#a78bfa",
  cargo_planes: "#ffb86c",
  office_lighting: "#ffd166",
  heating: "#ff6b6b",
  cooling: "#60a5fa",
  computing: "#93c5fd",
  subcontractors: "#c4b5fd",
};

function orderedColors() { return CATEGORY_ORDER.map((k) => CATEGORY_COLORS[k]); }
function orderedLabels() { return CATEGORY_ORDER.map((k) => CATEGORY_LABELS[k]); }

/* ------------------------------
   DOM References
   ------------------------------ */
const $ = (id) => document.getElementById(id);

// Activity inputs
const inputs = {
  cars_km: $("cars_km"),
  trucks_km: $("trucks_km"),
  buses_km: $("buses_km"),
  forklifts_hours: $("forklifts_hours"),
  planes_hours: $("planes_hours"),
  lighting_kwh: $("lighting_kwh"),
  heating_kwhth: $("heating_kwhth"),
  cooling_kwh: $("cooling_kwh"),
  computing_kwh: $("computing_kwh"),
  subcontractors_tons: $("subcontractors_tons"),
};

// Sliders + readouts
const sliders = {
  ev_share_pct: $("ev_share_pct"),
  km_reduction_pct: $("km_reduction_pct"),
  load_factor_pct: $("load_factor_pct"),
};
const sliderVals = {
  ev_share_pct: $("ev_value"),
  km_reduction_pct: $("km_value"),
  load_factor_pct: $("load_value"),
};

// CTA buttons
const btnCalculate = $("calculate-btn");
const btnLoad = $("load-btn");
const btnReset = $("reset-btn");

// KPIs
const kpiBaseline = $("baseline-total");
const kpiOptimized = $("optimized-total");
const kpiReduction = $("reduction-total");

// Charts
const pieDiv = $("pieChart");
const barDiv = $("barChart");

// Assumptions
const assumptionsList = $("assumptions-list");

// Recommendations (new panel)
const recList = $("recommendations-list"); // Ensure <ul id="recommendations-list">
const recRegion = $("recommendations-region"); // Optional wrapper for aria-live if present

/* ------------------------------
   Lightweight Toast System
   ------------------------------ */
let toastTimer = null;
function showToast(message, level = "info") {
  let el = document.getElementById("toast");
  if (!el) {
    el = document.createElement("div");
    el.id = "toast";
    el.setAttribute("role", "status");
    el.setAttribute("aria-live", "polite");
    document.body.appendChild(el);
  }
  el.className = `toast toast-${level} toast-visible`;
  el.textContent = message;

  if (toastTimer) clearTimeout(toastTimer);
  toastTimer = setTimeout(() => {
    el.classList.remove("toast-visible");
  }, 2800);
}

/* ------------------------------
   Formatting Utilities
   ------------------------------ */
function toNumber(value) {
  if (value === null || value === undefined || value === "") return 0;
  const n = Number(value);
  return Number.isFinite(n) ? n : 0;
}

function fmtTons(v) {
  const str = (Math.round(v * 100) / 100).toFixed(2);
  return str.replace(/\.00$/, "");
}

function percent(v) {
  const n = Math.round(v * 100) / 100;
  return `${n.toFixed(2).replace(/\.00$/, "")}%`;
}

/* ------------------------------
   Payload & Form Management
   ------------------------------ */
function getPayloadFromForm() {
  const activity = {
    cars_km: toNumber(inputs.cars_km.value),
    trucks_km: toNumber(inputs.trucks_km.value),
    buses_km: toNumber(inputs.buses_km.value),
    forklifts_hours: toNumber(inputs.forklifts_hours.value),
    planes_hours: toNumber(inputs.planes_hours.value),
    lighting_kwh: toNumber(inputs.lighting_kwh.value),
    heating_kwhth: toNumber(inputs.heating_kwhth.value),
    cooling_kwh: toNumber(inputs.cooling_kwh.value),
    computing_kwh: toNumber(inputs.computing_kwh.value),
    subcontractors_tons: toNumber(inputs.subcontractors_tons.value),
  };

  const slidersPayload = {
    ev_share_pct: toNumber(sliders.ev_share_pct.value),
    km_reduction_pct: toNumber(sliders.km_reduction_pct.value),
    load_factor_pct: toNumber(sliders.load_factor_pct.value),
  };

  return { activity, sliders: slidersPayload };
}

function populateFormFromSample(sample) {
  if (!sample || typeof sample !== "object") return;
  const { activity = {}, sliders: s = {} } = sample;

  Object.entries(activity).forEach(([k, v]) => {
    if (inputs[k]) inputs[k].value = toNumber(v);
  });

  if (typeof s.ev_share_pct !== "undefined") sliders.ev_share_pct.value = toNumber(s.ev_share_pct);
  if (typeof s.km_reduction_pct !== "undefined") sliders.km_reduction_pct.value = toNumber(s.km_reduction_pct);
  if (typeof s.load_factor_pct !== "undefined") sliders.load_factor_pct.value = toNumber(s.load_factor_pct);

  syncSliderReadouts();
}

function resetForm() {
  Object.values(inputs).forEach((el) => (el.value = 0));
  sliders.ev_share_pct.value = 0;
  sliders.km_reduction_pct.value = 0;
  sliders.load_factor_pct.value = 100;
  syncSliderReadouts();
}

/* ------------------------------
   Slider Readout Sync
   ------------------------------ */
function syncSliderReadouts() {
  sliderVals.ev_share_pct.textContent = `${toNumber(sliders.ev_share_pct.value)}%`;
  sliderVals.km_reduction_pct.textContent = `${toNumber(sliders.km_reduction_pct.value)}%`;
  sliderVals.load_factor_pct.textContent = `${toNumber(sliders.load_factor_pct.value)}%`;
}

/* ------------------------------
   Backend Communication (Fetch)
   ------------------------------ */
async function apiCalculate(payload) {
  const resp = await fetch("/calculate", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload),
  });
  if (!resp.ok) throw new Error(`Calculate failed: ${resp.status}`);
  return await resp.json();
}

async function apiLoadSample() {
  const resp = await fetch("/load_sample");
  if (!resp.ok) throw new Error(`Load sample failed: ${resp.status}`);
  return await resp.json();
}

async function apiReset() {
  const resp = await fetch("/reset", { method: "POST" });
  if (!resp.ok) throw new Error(`Reset failed: ${resp.status}`);
  return await resp.json();
}

/* ------------------------------
   Plotly Chart Initialization
   ------------------------------ */
function initPieChart() {
  const labels = orderedLabels();
  const values = CATEGORY_ORDER.map(() => 0);
  const colors = orderedColors();

  const data = [
    {
      type: "pie",
      labels,
      values,
      textinfo: "label+percent",
      insidetextorientation: "radial",
      hole: 0.35,
      marker: { colors, line: { color: "#0e1116", width: 2 } },
      hovertemplate: "%{label}<br>%{value:.2f} tCO₂e<br>%{percent}<extra></extra>",
      sort: false,
    },
  ];

  const layout = {
    paper_bgcolor: "rgba(0,0,0,0)",
    plot_bgcolor: "rgba(0,0,0,0)",
    font: { color: "#e9eef7" },
    margin: { t: 20, r: 20, b: 20, l: 20 },
    showlegend: false,
  };

  Plotly.newPlot(pieDiv, data, layout, { responsive: true, displayModeBar: false });
}

function initBarChart() {
  const x = orderedLabels();
  const colors = orderedColors();
  const zeros = CATEGORY_ORDER.map(() => 0);

  const baselineTrace = {
    x,
    y: zeros,
    type: "bar",
    name: "Baseline",
    marker: { color: colors, opacity: 0.92 },
    hovertemplate: "%{x}<br>%{y:.2f} tCO₂e<extra>Baseline</extra>",
  };

  const optimizedTrace = {
    x,
    y: zeros,
    type: "bar",
    name: "Optimized",
    marker: { color: colors.map((c) => adjustColor(c, -18)), opacity: 0.92 },
    hovertemplate: "%{x}<br>%{y:.2f} tCO₂e<extra>Optimized</extra>",
  };

  const layout = {
    barmode: "group",
    paper_bgcolor: "rgba(0,0,0,0)",
    plot_bgcolor: "rgba(0,0,0,0)",
    font: { color: "#e9eef7" },
    margin: { t: 20, r: 20, b: 50, l: 50 },
    xaxis: {
      tickangle: -10,
      gridcolor: "rgba(255,255,255,0.03)",
    },
    yaxis: {
      title: "tCO₂e",
      gridcolor: "rgba(255,255,255,0.06)",
      zerolinecolor: "rgba(255,255,255,0.2)",
    },
    legend: {
      x: 0.02,
      y: 1.08,
      orientation: "h",
      font: { size: 12 },
    },
  };

  Plotly.newPlot(barDiv, [baselineTrace, optimizedTrace], layout, {
    responsive: true,
    displayModeBar: false,
  });
}

// Color adjustment utility (RGB channel shift)
function adjustColor(hex, amt) {
  const c = hex.replace("#", "");
  const num = parseInt(c, 16);
  let r = (num >> 16) + amt;
  let g = ((num >> 8) & 0x00ff) + amt;
  let b = (num & 0x0000ff) + amt;
  r = Math.max(Math.min(255, r), 0);
  g = Math.max(Math.min(255, g), 0);
  b = Math.max(Math.min(255, b), 0);
  return "#" + (b | (g << 8) | (r << 16)).toString(16).padStart(6, "0");
}

/* ------------------------------
   Chart Updaters
   ------------------------------ */
function updateChartsFromResponse(resp) {
  if (!resp || !resp.categories || !resp.totals || !resp.shares) {
    console.warn("Unexpected response structure", resp);
    showToast("Unexpected response from server.", "warn");
    return;
  }

  // 1) KPI update
  const { totals } = resp;
  const base = toNumber(totals.baseline);
  const opt = toNumber(totals.optimized);
  const absRed = toNumber(totals.absolute_reduction);
  const pctRed = toNumber(totals.percent_reduction);

  kpiBaseline.textContent = `${fmtTons(base)} tCO₂e`;
  kpiOptimized.textContent = `${fmtTons(opt)} tCO₂e`;
  kpiReduction.textContent = `${fmtTons(absRed)} tCO₂e (${percent(pctRed)})`;

  // 2) Pie: optimized shares
  const optMap = resp.categories.optimized || {};
  const pieValues = CATEGORY_ORDER.map((k) => toNumber(optMap[k]));
  Plotly.react(
    pieDiv,
    [{
      type: "pie",
      labels: orderedLabels(),
      values: pieValues,
      textinfo: "label+percent",
      insidetextorientation: "radial",
      hole: 0.35,
      marker: { colors: orderedColors(), line: { color: "#0e1116", width: 2 } },
      hovertemplate: "%{label}<br>%{value:.2f} tCO₂e<br>%{percent}<extra></extra>",
      sort: false,
    }],
    {
      paper_bgcolor: "rgba(0,0,0,0)",
      plot_bgcolor: "rgba(0,0,0,0)",
      font: { color: "#e9eef7" },
      margin: { t: 20, r: 20, b: 20, l: 20 },
      showlegend: false,
    },
    { responsive: true, displayModeBar: false }
  );

  // 3) Bars: baseline vs optimized
  const baseMap = resp.categories.baseline || {};
  const barBaseline = CATEGORY_ORDER.map((k) => toNumber(baseMap[k]));
  const barOptimized = CATEGORY_ORDER.map((k) => toNumber(optMap[k]));
  const colors = orderedColors();
  const colorsOptimized = colors.map((c) => adjustColor(c, -18));

  Plotly.react(
    barDiv,
    [
      {
        x: orderedLabels(),
        y: barBaseline,
        type: "bar",
        name: "Baseline",
        marker: { color: colors, opacity: 0.92 },
        hovertemplate: "%{x}<br>%{y:.2f} tCO₂e<extra>Baseline</extra>",
      },
      {
        x: orderedLabels(),
        y: barOptimized,
        type: "bar",
        name: "Optimized",
        marker: { color: colorsOptimized, opacity: 0.92 },
        hovertemplate: "%{x}<br>%{y:.2f} tCO₂e<extra>Optimized</extra>",
      },
    ],
    {
      barmode: "group",
      paper_bgcolor: "rgba(0,0,0,0)",
      plot_bgcolor: "rgba(0,0,0,0)",
      font: { color: "#e9eef7" },
      margin: { t: 20, r: 20, b: 50, l: 50 },
      xaxis: { tickangle: -10, gridcolor: "rgba(255,255,255,0.03)" },
      yaxis: { title: "tCO₂e", gridcolor: "rgba(255,255,255,0.06)", zerolinecolor: "rgba(255,255,255,0.2)" },
      legend: { x: 0.02, y: 1.08, orientation: "h", font: { size: 12 } },
    },
    { responsive: true, displayModeBar: false }
  );

  // 4) Recommendations (NEW) + Assumptions
  renderRecommendations(resp.recommendations || []);
  renderAssumptions(resp.assumptions || []);
}

/* ------------------------------
   Recommendations Renderer (Premium)
   - Minimalist professional styles
   - Emoji icons (no external libs)
   - Subtle fade/slide animation
   ------------------------------ */
function renderRecommendations(list) {
  if (!recList) return;
  recList.innerHTML = "";

  if (!Array.isArray(list) || list.length === 0) {
    const li = document.createElement("li");
    li.className = "rec-item neutral fade-in-up";
    li.textContent = "No recommendations at this time. Keep monitoring your sustainability performance.";
    recList.appendChild(li);
    return;
  }

  list.forEach((msg, idx) => {
    const li = document.createElement("li");
    li.className = "rec-item fade-in-up";

    // Classify by semantics
    let icon = "💡";
    if (/excellent|great|strong/i.test(msg)) {
      li.classList.add("success");
      icon = "✅";
    } else if (/high|significant|large/i.test(msg)) {
      li.classList.add("danger");
      icon = "⚠️";
    } else if (/low reduction|underused|low/i.test(msg)) {
      li.classList.add("warning");
      icon = "🔎";
    } else {
      li.classList.add("neutral");
      icon = "💡";
    }

    // Add category hint emojis when relevant
    if (/air cargo|load factor|flight/i.test(msg)) icon = "✈️";
    if (/truck/i.test(msg)) icon = "🚛";
    if (/EV|electric/i.test(msg)) icon = "🔌";

    // Content
    const wrap = document.createElement("div");
    wrap.className = "rec-line";
    const iconSpan = document.createElement("span");
    iconSpan.className = "rec-icon";
    iconSpan.textContent = icon;

    const textSpan = document.createElement("span");
    textSpan.className = "rec-text";
    textSpan.textContent = msg;

    wrap.appendChild(iconSpan);
    wrap.appendChild(textSpan);
    li.appendChild(wrap);

    // Staggered animation for professional feel
    li.style.animationDelay = `${Math.min(idx * 80, 400)}ms`;
    recList.appendChild(li);
  });

  // Optional aria-live region update
  if (recRegion) {
    recRegion.setAttribute("aria-live", "polite");
    recRegion.setAttribute("role", "status");
  }
}

/* ------------------------------
   Assumptions Renderer
   ------------------------------ */
function renderAssumptions(list) {
  assumptionsList.innerHTML = "";
  if (!Array.isArray(list)) return;
  list.forEach((text) => {
    const li = document.createElement("li");
    li.textContent = text;
    assumptionsList.appendChild(li);
  });
}

/* ------------------------------
   Action Handlers
   ------------------------------ */
async function onCalculate() {
  try {
    const payload = getPayloadFromForm();
    const resp = await apiCalculate(payload);
    updateChartsFromResponse(resp);
    showToast("Calculation updated", "ok");
  } catch (err) {
    console.error(err);
    showToast("Failed to calculate emissions.", "error");
  }
}

async function onLoadSample() {
  try {
    const sample = await apiLoadSample();
    populateFormFromSample(sample);
    const resp = await apiCalculate(sample);
    updateChartsFromResponse(resp);
    showToast("Sample loaded", "ok");
  } catch (err) {
    console.error(err);
    showToast("Failed to load sample data.", "error");
  }
}

async function onReset() {
  try {
    await apiReset();
    resetForm();
    const resp = await apiCalculate(getPayloadFromForm());
    updateChartsFromResponse(resp);
    showToast("Form reset", "ok");
  } catch (err) {
    console.error(err);
    showToast("Reset failed.", "error");
  }
}

/* ------------------------------
   Initialization
   ------------------------------ */
function bindEvents() {
  btnCalculate.addEventListener("click", onCalculate);
  btnLoad.addEventListener("click", onLoadSample);
  btnReset.addEventListener("click", onReset);

  sliders.ev_share_pct.addEventListener("input", () => {
    sliderVals.ev_share_pct.textContent = `${toNumber(sliders.ev_share_pct.value)}%`;
  });
  sliders.km_reduction_pct.addEventListener("input", () => {
    sliderVals.km_reduction_pct.textContent = `${toNumber(sliders.km_reduction_pct.value)}%`;
  });
  sliders.load_factor_pct.addEventListener("input", () => {
    sliderVals.load_factor_pct.textContent = `${toNumber(sliders.load_factor_pct.value)}%`;
  });

  // Enter key triggers calculate from any numeric input
  Object.values(inputs).forEach((el) => {
    el.addEventListener("keydown", (e) => {
      if (e.key === "Enter") {
        e.preventDefault();
        onCalculate();
      }
    });
  });
}

async function initialRender() {
  // Set initial slider labels
  syncSliderReadouts();

  // Initialize charts
  initPieChart();
  initBarChart();

  // Preload sample for meaningful first view
  try {
    const sample = await apiLoadSample();
    populateFormFromSample(sample);
    const resp = await apiCalculate(sample);
    updateChartsFromResponse(resp);
  } catch (e) {
    // Fallback: zeros
    const resp = await apiCalculate(getPayloadFromForm());
    updateChartsFromResponse(resp);
  }
}

// DOM Ready
window.addEventListener("DOMContentLoaded", () => {
  bindEvents();
  initialRender();
});

/* ==========================================================================
   Optional: CSS hooks expected by this JS (add these to your CSS file)
   --------------------------------------------------------------------------
   .recommendations-container { margin-top: 16px; }
   .recommendations-list { list-style: none; padding: 0; margin: 8px 0 0; }
   .rec-item { 
     display: block;
     padding: 10px 12px; 
     border-radius: 12px; 
     margin-bottom: 8px; 
     font-size: 0.95rem; 
     background: rgba(255,255,255,0.04);
     border: 1px solid rgba(255,255,255,0.06);
     backdrop-filter: blur(4px);
     box-shadow: 0 2px 10px rgba(0,0,0,0.12);
   }
   .rec-line { display: flex; align-items: center; gap: 10px; }
   .rec-icon { font-size: 1.05rem; line-height: 1; }
   .rec-text { color: #e9eef7; }

   .rec-item.success { background: linear-gradient(135deg, rgba(28,134,87,0.28), rgba(28,134,87,0.10)); border-color: rgba(28,134,87,0.35); }
   .rec-item.warning { background: linear-gradient(135deg, rgba(200,162,0,0.28), rgba(200,162,0,0.10)); border-color: rgba(200,162,0,0.36); }
   .rec-item.danger  { background: linear-gradient(135deg, rgba(179,13,13,0.28), rgba(179,13,13,0.10)); border-color: rgba(179,13,13,0.36); }
   .rec-item.neutral { background: linear-gradient(135deg, rgba(58,63,71,0.32), rgba(58,63,71,0.12)); border-color: rgba(102,112,124,0.30); }

   .fade-in-up {
     opacity: 0;
     transform: translateY(8px);
     animation: fadeUp 340ms ease forwards;
   }
   @keyframes fadeUp {
     to { opacity: 1; transform: translateY(0); }
   }

   .toast {
     position: fixed;
     bottom: 22px;
     right: 22px;
     padding: 10px 14px;
     border-radius: 10px;
     font-size: 0.95rem;
     color: #0e1116;
     background: #e9eef7;
     box-shadow: 0 10px 30px rgba(0,0,0,0.18);
     opacity: 0; transform: translateY(10px);
     transition: all .25s ease;
     z-index: 9999;
   }
   .toast-visible { opacity: 1; transform: translateY(0); }
   .toast-ok    { background: #b8f3d6; color: #0f3b2b; }
   .toast-warn  { background: #ffe9a8; color: #5a4805; }
   .toast-error { background: #ffd4d4; color: #5a0b0b; }
   ========================================================================== */
