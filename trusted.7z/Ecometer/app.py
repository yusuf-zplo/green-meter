# app.py
# Green Meter App — Flask backend
# Connects templates, static assets, calculation engine, and JSON API routes.

from __future__ import annotations

import os
import json
from datetime import datetime
from typing import Dict, Any

from flask import (
    Flask,
    render_template,
    request,
    jsonify,
    redirect,
    url_for,
    make_response,
    abort,
)

# Calculation engine + sample payloads
from emissions_engine import calculate_response, get_sample_data


def create_app() -> Flask:
    app = Flask(
        __name__,
        static_folder="static",
        template_folder="templates",
    )

    # -----------------------------
    # Basic Security & Caching
    # -----------------------------
    @app.after_request
    def add_security_headers(resp):
        # Security headers (conservative)
        resp.headers["X-Content-Type-Options"] = "nosniff"
        resp.headers["X-Frame-Options"] = "SAMEORIGIN"
        resp.headers["X-XSS-Protection"] = "1; mode=block"
        # Front-end assets change often during dev; keep short cache
        if resp.mimetype in ("text/html", "application/json"):
            resp.headers["Cache-Control"] = "no-store"
        return resp

    # -----------------------------
    # Helpers
    # -----------------------------
    def _default_payload() -> Dict[str, Any]:
        """Zeroed activity with neutral sliders (what Reset uses)."""
        return {
            "activity": {
                "cars_km": 0,
                "trucks_km": 0,
                "buses_km": 0,
                "forklifts_hours": 0,
                "planes_hours": 0,
                "lighting_kwh": 0,
                "heating_kwhth": 0,
                "cooling_kwh": 0,
                "computing_kwh": 0,
                "subcontractors_tons": 0,
            },
            "sliders": {
                "ev_share_pct": 0,
                "km_reduction_pct": 0,
                "load_factor_pct": 100,
            },
        }

    def _json_error(message: str, status: int = 400):
        return jsonify({"error": message, "status": status}), status

    # -----------------------------
    # Routes
    # -----------------------------
    @app.route("/", methods=["GET"])
    def index():
        # Render the main dashboard (index.html extends layout.html)
        current_year = datetime.utcnow().year
        return render_template("index.html", year=current_year)

    @app.route("/calculate", methods=["POST"])
    def calculate():
        """
        Accepts JSON payload:
        {
          "activity": {...},
          "sliders": {...}
        }
        Returns structure from calculate_response(...) ready for charts.js.
        """
        if not request.is_json:
            return _json_error("Expected JSON payload.", 415)

        try:
            payload = request.get_json(force=True, silent=False)
        except Exception as e:
            return _json_error(f"Invalid JSON: {e}", 400)

        try:
            result = calculate_response(payload or {})
        except ValueError as ve:
            # Input validation errors from engine
            return _json_error(str(ve), 400)
        except Exception as e:
            return _json_error(f"Calculation failed: {e}", 500)

        return jsonify(result)

    @app.route("/load_sample", methods=["GET"])
    def load_sample():
        """
        Returns a realistic example payload with activity and sliders filled,
        matching the UI fields. charts.js will also auto-calculate after load.
        """
        try:
            sample = get_sample_data()
        except Exception as e:
            return _json_error(f"Could not load sample data: {e}", 500)
        return jsonify(sample)

    @app.route("/reset", methods=["POST"])
    def reset():
        """
        Resets UI to default payload (zeros + neutral sliders).
        Front-end resets DOM and then may re-run /calculate to clear charts.
        """
        return jsonify(_default_payload())

    # Optional simple health probe for deployment
    @app.route("/healthz", methods=["GET"])
    def healthz():
        return jsonify({"status": "ok", "time": datetime.utcnow().isoformat() + "Z"})

    # Friendly 404 for unknown routes
    @app.errorhandler(404)
    def not_found(_e):
        # For API paths, respond JSON; otherwise redirect home
        if request.path.startswith("/api") or request.is_json:
            return _json_error("Not Found", 404)
        return redirect(url_for("index"))

    return app


# ---------------
# Entrypoint
# ---------------
if __name__ == "__main__":
    # Create the app
    app = create_app()

    # Host/port can be overridden via environment variables
    host = os.environ.get("FLASK_RUN_HOST", "0.0.0.0")
    port = int(os.environ.get("FLASK_RUN_PORT", "5000"))
    debug = os.environ.get("FLASK_DEBUG", "0") == "1"

    app.run(host=host, port=port, debug=debug)
