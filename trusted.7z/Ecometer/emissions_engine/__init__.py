"""
emissions_engine package initializer.

This package contains:
- formulas.py: Core carbon emission calculations
- sample_data.py: Default dataset for demo mode

This file enables clean package imports:
`from emissions_engine.formulas import calculate_response`
"""
# Explicit re-export for convenience
from .formulas import calculate_response
from .sample_data import get_sample_data

__all__ = [
    "calculate_response",
    "get_sample_data",
]
