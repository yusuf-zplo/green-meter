"""
emissions_engine/sample_data.py

Provides sample input data for the Green Meter App,
inspired by the UI examples provided.

This dataset ensures every category is populated and
will show meaningful results in charts immediately
after clicking "Load Sample Data".

All values represent annual activity data.
"""


# Default realistic dataset (full logistic operation scenario)
SAMPLE_DATA = {
    "activity": {
        # Transportation
        "cars_km": 250000,          # km / year
        "trucks_km": 150000,        # km / year
        "buses_km": 80000,          # km / year

        # Equipment
        "forklifts_hours": 2000,    # operating hours / year
        "planes_hours": 450,        # flight hours / year

        # Buildings & Facilities
        "lighting_kwh": 120000,     # kWh / year
        "heating_kwhth": 90000,     # kWh-thermal / year
        "cooling_kwh": 300000,      # kWh / year

        # Computing
        "computing_kwh": 99000,     # kWh / year

        # Subcontractors
        "subcontractors_tons": 45,  # tons CO2e / year (direct entry)
    },

    # Adjustment sliders – matching sample GUI
    "sliders": {
        "ev_share_pct": 30,         # 30% of KM are EV
        "km_reduction_pct": 5,      # 5% less total KM
        "load_factor_pct": 80       # Planes operate at 80% of baseline load
    }
}


def get_sample_data() -> dict:
    """
    Returns a deep copy of SAMPLE_DATA so the caller can
    modify the returned object without affecting the original.
    """
    import copy
    return copy.deepcopy(SAMPLE_DATA)
