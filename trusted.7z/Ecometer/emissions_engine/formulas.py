"""
emissions_engine/formulas.py

Carbon emission calculation engine for the Green Meter App.

Implements:
- Per-category emissions (tons CO2e) using provided factors and formulas
- Baseline vs. Optimized scenarios
- Input validation and normalization helpers
- Totals, absolute & % reduction, and category shares
- API-friendly response formatting
- Recommendations and alert logic (NEW)

All outputs are expressed in *tons CO2e*.
"""

from __future__ import annotations
from dataclasses import dataclass, asdict
from typing import Dict, Any


# -----------------------------
# Emission factors (kg CO2e / unit)
# -----------------------------
EMISSION_FACTORS = {
    "cars_per_km": 0.18,          # kg / km
    "trucks_per_km": 0.90,        # kg / km
    "buses_per_km": 1.10,         # kg / km
    "forklifts_per_hr": 4.0,      # kg / hour
    "planes_per_hr": 9000.0,      # kg / hour
    "electricity_per_kwh": 0.42,  # kg / kWh  (office lighting, cooling, computing)
    "heating_per_kwhth": 0.20,    # kg / kWh-thermal
}

# Master ordering for charts + API
CATEGORY_KEYS = [
    "cars",
    "trucks",
    "buses",
    "forklifts",
    "cargo_planes",
    "office_lighting",
    "heating",
    "cooling",
    "computing",
    "subcontractors",
]


# -----------------------------
# Input models and validation
# -----------------------------
@dataclass
class ActivityData:
    """All activity inputs for a single calculation (annual values)."""
    cars_km: float = 0.0
    trucks_km: float = 0.0
    buses_km: float = 0.0
    forklifts_hours: float = 0.0
    planes_hours: float = 0.0
    lighting_kwh: float = 0.0
    heating_kwhth: float = 0.0
    cooling_kwh: float = 0.0
    computing_kwh: float = 0.0
    subcontractors_tons: float = 0.0  # already in tons CO2e

    @staticmethod
    def from_payload(payload: Dict[str, Any]) -> "ActivityData":
        """Cast inputs into valid floats; empty/missing -> 0."""
        def num(x):
            if x is None or x == "":
                return 0.0
            if isinstance(x, (int, float)):
                return float(x)
            try:
                return float(str(x).strip())
            except Exception as e:
                raise ValueError(f"Invalid numeric input: {x}") from e

        return ActivityData(
            cars_km=num(payload.get("cars_km", 0)),
            trucks_km=num(payload.get("trucks_km", 0)),
            buses_km=num(payload.get("buses_km", 0)),
            forklifts_hours=num(payload.get("forklifts_hours", 0)),
            planes_hours=num(payload.get("planes_hours", 0)),
            lighting_kwh=num(payload.get("lighting_kwh", 0)),
            heating_kwhth=num(payload.get("heating_kwhth", 0)),
            cooling_kwh=num(payload.get("cooling_kwh", 0)),
            computing_kwh=num(payload.get("computing_kwh", 0)),
            subcontractors_tons=num(payload.get("subcontractors_tons", 0)),
        )

    def validate_nonnegative(self):
        """Ensure user can’t input negative usage."""
        for k, v in asdict(self).items():
            if v < 0:
                raise ValueError(f"{k} cannot be negative (got {v}).")


@dataclass
class OptimizationSliders:
    """Inputs modifying only Cars + Cargo Planes emissions."""
    ev_share_pct: float = 0.0
    km_reduction_pct: float = 0.0
    load_factor_pct: float = 100.0

    @staticmethod
    def from_payload(payload: Dict[str, Any]) -> "OptimizationSliders":
        def pct(x):
            if x is None or x == "":
                return 0.0
            if isinstance(x, (int, float)):
                return float(x)
            try:
                return float(str(x).strip())
            except Exception as e:
                raise ValueError(f"Invalid percentage input: {x}") from e

        return OptimizationSliders(
            ev_share_pct=pct(payload.get("ev_share_pct", 0)),
            km_reduction_pct=pct(payload.get("km_reduction_pct", 0)),
            load_factor_pct=pct(payload.get("load_factor_pct", 100)),
        )

    def validate_ranges(self):
        if not (0 <= self.ev_share_pct <= 100):
            raise ValueError("ev_share_pct must be between 0 and 100.")
        if not (0 <= self.km_reduction_pct <= 100):
            raise ValueError("km_reduction_pct must be between 0 and 100.")
        if not (0 <= self.load_factor_pct <= 100):
            raise ValueError("load_factor_pct must be between 0 and 100.")


# -----------------------------
# Core per-category calculations
# -----------------------------
def _kg_to_tons(value_kg: float) -> float:
    return value_kg / 1000.0


def cars_tons_baseline(km: float) -> float:
    return _kg_to_tons(km * EMISSION_FACTORS["cars_per_km"])


def cars_tons_optimized(km: float, ev_pct: float, km_pct: float) -> float:
    """
    Full optimized formula:
    ((km * 0.18) * (1 - 0.7 * EV%) * (1 - KM reduction%)) / 1000
    """
    base_kg = km * EMISSION_FACTORS["cars_per_km"]
    ev_term = 1 - (0.7 * (ev_pct / 100))
    km_term = 1 - (km_pct / 100)
    return _kg_to_tons(max(base_kg * ev_term * km_term, 0))


def trucks_tons(km: float) -> float:
    return _kg_to_tons(km * EMISSION_FACTORS["trucks_per_km"])


def buses_tons(km: float) -> float:
    return _kg_to_tons(km * EMISSION_FACTORS["buses_per_km"])


def forklifts_tons(hours: float) -> float:
    return _kg_to_tons(hours * EMISSION_FACTORS["forklifts_per_hr"])


def planes_tons_baseline(hours: float) -> float:
    return _kg_to_tons(hours * EMISSION_FACTORS["planes_per_hr"])


def planes_tons_optimized(hours: float, load_factor_pct: float) -> float:
    base_kg = hours * EMISSION_FACTORS["planes_per_hr"]
    mod = load_factor_pct / 100.0
    return _kg_to_tons(max(base_kg * mod, 0))


def electricity_tons(kwh: float) -> float:
    return _kg_to_tons(kwh * EMISSION_FACTORS["electricity_per_kwh"])


def heating_tons(kwhth: float) -> float:
    return _kg_to_tons(kwhth * EMISSION_FACTORS["heating_per_kwhth"])


def subcontractors_tons(tons_value: float) -> float:
    return max(tons_value, 0.0)


# -----------------------------
# Aggregate calculators
# -----------------------------
def calculate_baseline(a: ActivityData) -> Dict[str, float]:
    a.validate_nonnegative()
    result = {
        "cars": cars_tons_baseline(a.cars_km),
        "trucks": trucks_tons(a.trucks_km),
        "buses": buses_tons(a.buses_km),
        "forklifts": forklifts_tons(a.forklifts_hours),
        "cargo_planes": planes_tons_baseline(a.planes_hours),
        "office_lighting": electricity_tons(a.lighting_kwh),
        "heating": heating_tons(a.heating_kwhth),
        "cooling": electricity_tons(a.cooling_kwh),
        "computing": electricity_tons(a.computing_kwh),
        "subcontractors": subcontractors_tons(a.subcontractors_tons),
    }
    return {k: round(v, 2) for k, v in result.items()}


def calculate_optimized(a: ActivityData, s: OptimizationSliders) -> Dict[str, float]:
    a.validate_nonnegative()
    s.validate_ranges()
    result = {
        "cars": cars_tons_optimized(a.cars_km, s.ev_share_pct, s.km_reduction_pct),
        "trucks": trucks_tons(a.trucks_km),
        "buses": buses_tons(a.buses_km),
        "forklifts": forklifts_tons(a.forklifts_hours),
        "cargo_planes": planes_tons_optimized(a.planes_hours, s.load_factor_pct),
        "office_lighting": electricity_tons(a.lighting_kwh),
        "heating": heating_tons(a.heating_kwhth),
        "cooling": electricity_tons(a.cooling_kwh),
        "computing": electricity_tons(a.computing_kwh),
        "subcontractors": subcontractors_tons(a.subcontractors_tons),
    }
    return {k: round(v, 2) for k, v in result.items()}


def _sum_categories(cat_map: Dict[str, float]) -> float:
    return round(sum(cat_map.get(k, 0.0) for k in CATEGORY_KEYS), 2)


def _shares(cat_map: Dict[str, float]) -> Dict[str, float]:
    total = sum(cat_map.values()) or 1.0
    return {k: round((cat_map.get(k, 0.0) / total) * 100.0, 2) for k in CATEGORY_KEYS}


def compare_scenarios(baseline: Dict[str, float], optimized: Dict[str, float]) -> Dict[str, Any]:
    total_b = _sum_categories(baseline)
    total_o = _sum_categories(optimized)
    abs_red = round(total_b - total_o, 2)
    pct_red = round((abs_red / total_b) * 100.0, 2) if total_b > 0 else 0.0

    return {
        "categories": {
            "baseline": {k: baseline.get(k, 0.0) for k in CATEGORY_KEYS},
            "optimized": {k: optimized.get(k, 0.0) for k in CATEGORY_KEYS},
        },
        "totals": {
            "baseline": total_b,
            "optimized": total_o,
            "absolute_reduction": abs_red,
            "percent_reduction": pct_red,
        },
        "shares": {
            "baseline": _shares(baseline),
            "optimized": _shares(optimized),
        },
        "order": CATEGORY_KEYS,
    }


# -----------------------------
# Recommendation Engine (NEW)
# -----------------------------
def _generate_recommendations(comp: Dict[str, Any]) -> list:
    recs = []

    totals = comp["totals"]
    baseline = comp["categories"]["baseline"]
    pct_red = totals["percent_reduction"]

    if totals["baseline"] > 1000:
        recs.append("High overall emissions detected — consider aggressive EV adoption and route optimization.")

    if baseline["cargo_planes"] > 200:
        recs.append("Air cargo emissions are significant — improve load factors or shift toward land/sea transport.")

    if baseline["trucks"] > 200:
        recs.append("Truck emissions are high — consider load consolidation and more efficient logistics scheduling.")

    if pct_red < 15:
        recs.append("Low reduction from optimizations — increase EV share and apply stronger distance reduction targets.")

    if pct_red >= 40:
        recs.append("Excellent optimization! You achieved strong CO₂ reductions — keep expanding sustainability actions!")

    if not recs:
        recs.append("Performance is good — emissions remain manageable. Continue monitoring and improving where possible.")

    return recs


# -----------------------------
# Final wrapper used by API
# -----------------------------
def calculate_response(payload: Dict[str, Any]) -> Dict[str, Any]:
    activity = ActivityData.from_payload(payload.get("activity", payload))
    sliders = OptimizationSliders.from_payload(payload.get("sliders", payload))

    baseline = calculate_baseline(activity)
    optimized = calculate_optimized(activity, sliders)
    comparison = compare_scenarios(baseline, optimized)

    # Add recommendations ✨
    comparison["recommendations"] = _generate_recommendations(comparison)

    # Assumptions always returned
    comparison["assumptions"] = [
        "Units: Distance = km/year; Electricity = kWh/year; Heating = kWh-thermal/year; Planes = hours/year; Forklifts = hours/year; Subcontractors = tons/year.",
        "Sliders affect: Cars → EV Share (−70% on EV km) and KM Reduction; Cargo Planes → Load Factor (% of baseline).",
        "Other categories remain unchanged by optimization inputs.",
    ]

    return comparison
